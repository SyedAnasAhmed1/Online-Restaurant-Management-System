<section class="infomodal">
	<div id="modal3" class="modal">
	    <div class="modal-content">
	      <h4 id="info-modal-heading"></h4>
	      <p id="info-modal-content"></p>
	    </div>
	    <div class="modal-footer">
	      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Close</a>
	    </div>
	  </div>
  </section>